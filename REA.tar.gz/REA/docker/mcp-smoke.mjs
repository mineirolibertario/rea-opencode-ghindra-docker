#!/usr/bin/env node
// Minimal MCP streamable-HTTP smoke test used by scripts/test-mcp.sh.
// No SDK dependency: initialize -> notifications/initialized -> tools/list ->
// tools/call binary_session -> DELETE session.

const url = process.env.REA_MCP_URL ?? "http://127.0.0.1:8765/mcp";
let sessionId = "";

function parseResponse(text, contentType) {
  if (contentType.includes("text/event-stream")) {
    for (const block of text.split(/\r?\n\r?\n/)) {
      const data = block
        .split(/\r?\n/)
        .filter((line) => line.startsWith("data:"))
        .map((line) => line.slice(5).replace(/^ /, ""))
        .join("\n");
      if (data) {
        try {
          return JSON.parse(data);
        } catch {
          // Keep looking for the JSON event.
        }
      }
    }
    throw new Error("response did not contain a JSON SSE event");
  }
  return JSON.parse(text);
}

async function post(body, { notification = false } = {}) {
  const headers = {
    "content-type": "application/json",
    accept: "application/json, text/event-stream",
  };
  if (sessionId) headers["mcp-session-id"] = sessionId;

  const response = await fetch(url, {
    method: "POST",
    headers,
    body: JSON.stringify(body),
  });
  const nextSession = response.headers.get("mcp-session-id");
  if (nextSession) sessionId = nextSession;

  const text = await response.text();
  if (!response.ok) {
    throw new Error(`${response.status} ${response.statusText}: ${text}`);
  }
  if (notification) {
    if (response.status !== 202 && response.status !== 200) {
      throw new Error(`notification returned unexpected status ${response.status}`);
    }
    return undefined;
  }
  return parseResponse(text, response.headers.get("content-type") ?? "");
}

if (!url.startsWith("http://") && !url.startsWith("https://")) {
  throw new Error(`REA_MCP_URL must be an absolute HTTP URL, got ${url}`);
}

const initialized = await post({
  jsonrpc: "2.0",
  id: 1,
  method: "initialize",
  params: {
    protocolVersion: "2025-06-18",
    capabilities: {},
    clientInfo: { name: "rea-docker-smoke", version: "1.0.0" },
  },
});

const server = initialized?.result?.serverInfo;
if (!server || !sessionId) {
  throw new Error(`initialize failed: ${JSON.stringify(initialized)}`);
}

await post({ jsonrpc: "2.0", method: "notifications/initialized" }, { notification: true });

const listed = await post(
  { jsonrpc: "2.0", id: 2, method: "tools/list", params: {} },
  { notification: false },
);
const tools = listed?.result?.tools;
if (!Array.isArray(tools) || tools.length === 0) {
  throw new Error(`tools/list failed: ${JSON.stringify(listed)}`);
}

const status = await post(
  {
    jsonrpc: "2.0",
    id: 3,
    method: "tools/call",
    params: { name: "binary_session", arguments: {} },
  },
  { notification: false },
);

await fetch(url, {
  method: "DELETE",
  headers: { "mcp-session-id": sessionId },
});

console.log(`url:            ${url}`);
console.log(`server:         ${server.name ?? "?"} ${server.version ?? ""}`.trim());
console.log(`session:        ${sessionId}`);
console.log(`tools:          ${tools.length}`);
console.log(`first tools:    ${tools.slice(0, 8).map((tool) => tool.name).join(", ")}`);
console.log(
  `binary_session: ${status?.result?.isError ? "isError" : "ok"} ` +
    `(${JSON.stringify(status?.result?.structuredContent ?? {}).slice(0, 200)})`,
);

if (status?.result?.isError) {
  process.exitCode = 1;
}
