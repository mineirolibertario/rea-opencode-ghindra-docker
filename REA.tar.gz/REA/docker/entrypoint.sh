#!/bin/sh
# Resolve the JDK that Ghidra/Apktool/JADX should use, and export the tool
# locations that were actually installed into this image. Values supplied by
# the caller always win.
set -eu

if [ -z "${JAVA_HOME:-}" ]; then
  javac_bin="$(command -v javac 2>/dev/null || true)"
  if [ -n "$javac_bin" ]; then
    javac_real="$(readlink -f "$javac_bin")"
    JAVA_HOME="$(dirname "$(dirname "$javac_real")")"
    export JAVA_HOME
  fi
fi

if [ -z "${GHIDRA_INSTALL_DIR:-}" ] && [ -x /opt/ghidra/support/analyzeHeadless ]; then
  export GHIDRA_INSTALL_DIR=/opt/ghidra
fi

if [ -z "${REA_JADX_MCP_JAR:-}" ] && [ -f /opt/rea-tools/jadx-headless-mcp.jar ]; then
  export REA_JADX_MCP_JAR=/opt/rea-tools/jadx-headless-mcp.jar
fi

if [ -z "${REA_APKTOOL_COMMAND:-}" ] && [ -x /usr/local/bin/apktool ]; then
  export REA_APKTOOL_COMMAND=/usr/local/bin/apktool
fi

if [ -z "${REA_ADB_PATH:-}" ] && [ -x /opt/android-platform-tools/platform-tools/adb ]; then
  export REA_ADB_PATH=/opt/android-platform-tools/platform-tools/adb
fi

if [ -z "${REA_BROWSER_EXECUTABLE:-}" ] && [ -x /usr/bin/chromium ]; then
  export REA_BROWSER_EXECUTABLE=/usr/bin/chromium
fi

if [ -x /usr/bin/tshark ]; then
  export REA_TSHARK_COMMAND="${REA_TSHARK_COMMAND:-/usr/bin/tshark}"
  export REA_CAPINFOS_COMMAND="${REA_CAPINFOS_COMMAND:-/usr/bin/capinfos}"
  export REA_TSHARK_PRLIMIT_COMMAND="${REA_TSHARK_PRLIMIT_COMMAND:-/usr/bin/prlimit}"
fi

if [ -x /usr/bin/prlimit ]; then
  export REA_FIRMWARE_PRLIMIT_COMMAND="${REA_FIRMWARE_PRLIMIT_COMMAND:-/usr/bin/prlimit}"
fi

if [ -x /usr/bin/python3 ]; then
  export REA_PWNTOOLS_PYTHON="${REA_PWNTOOLS_PYTHON:-/usr/bin/python3}"
fi

# Containers are often started with an arbitrary host UID/GID. Fall back to a
# world-writable HOME when the image's /home/node is not writable.
if [ -z "${HOME:-}" ] || [ ! -w "${HOME}" ]; then
  HOME=/tmp/rea-home
  export HOME
fi
mkdir -p "$HOME" 2>/dev/null || true

# Seed the bundled REA skill into the caller's home. The skill identity check
# in `rea doctor` reads this directory; installing it here keeps the container
# healthy even when HOME falls back to /tmp/rea-home for an arbitrary UID.
skill_src=/opt/rea-skill/.agents/skills/reverse-engineer-anything
skill_dst="$HOME/.agents/skills/reverse-engineer-anything"
if [ -d "$skill_src" ] && [ ! -d "$skill_dst" ]; then
  mkdir -p "$HOME/.agents/skills" 2>/dev/null || true
  cp -a "$skill_src" "$HOME/.agents/skills/" 2>/dev/null || true
fi

export XDG_CACHE_HOME="${XDG_CACHE_HOME:-$HOME/.cache}"
mkdir -p "$XDG_CACHE_HOME" 2>/dev/null || true

exec "$@"
