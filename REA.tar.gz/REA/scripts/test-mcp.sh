#!/usr/bin/env bash
# Build and smoke-test the REA MCP container.
#
# Usage:
#   scripts/test-mcp.sh              # build, doctor, toolchain, start HTTP, MCP smoke test
#   scripts/test-mcp.sh --no-build   # reuse the current rea-mcp:local image
#   scripts/test-mcp.sh --stop       # stop the compose service when finished
set -euo pipefail

cd "$(dirname "$0")/.."

build=1
stop=0
for arg in "$@"; do
  case "$arg" in
    --no-build) build=0 ;;
    --stop) stop=1 ;;
    -h|--help)
      sed -n '2,9p' "$0" | sed 's/^# \{0,1\}//'
      exit 0
      ;;
    *)
      echo "unknown argument: $arg" >&2
      exit 2
      ;;
  esac
done

if ! docker compose version >/dev/null 2>&1; then
  echo "docker compose (v2) is required" >&2
  exit 2
fi
if ! command -v jq >/dev/null 2>&1; then
  echo "jq is required for the provider assertions (apt install jq)" >&2
  exit 2
fi

if [[ $build -eq 1 ]]; then
  echo "==> Building image"
  docker compose build
fi

echo "==> REA version"
docker compose run --rm --no-deps -T rea rea --version

echo "==> Provider readiness (rea doctor)"
set +e
docker compose run --rm --no-deps -T rea rea doctor
doctor_status=$?
set -e
if [[ $doctor_status -ne 0 ]]; then
  echo "rea doctor exited ${doctor_status}; checking required providers below."
fi

# Assert the checks this image is responsible for; optional commercial engines
# (Hopper/IDA/Kuna) are expected to be absent.
doctor_json="$(docker compose run --rm --no-deps -T rea rea doctor --format json 2>/dev/null || true)"
if [[ -z "$doctor_json" ]]; then
  echo "could not read 'rea doctor --format json'" >&2
  exit 1
fi

required_checks=(ghidra ghidra-version ghidra-headless ghidra-native_decompiler ghidra-java jadx)
failed=0
for check in "${required_checks[@]}"; do
  if jq -e --arg name "$check" \
    '.scope_checks[] | select(.name == $name and .ok == true)' \
    <<<"$doctor_json" >/dev/null; then
    echo "  ok: ${check}"
  else
    echo "  FAILED: ${check}" >&2
    failed=1
  fi
done
if ! jq -e '.identity.skill.state == "aligned"' <<<"$doctor_json" >/dev/null; then
  echo "  FAILED: bundled skill identity (expected aligned)" >&2
  failed=1
else
  echo "  ok: skill:identity"
fi
if [[ $failed -ne 0 ]]; then
  echo "required provider checks failed" >&2
  exit 1
fi

echo "==> Toolchain"
docker compose run --rm --no-deps -T rea sh -c '
  set -e
  echo "apktool:  $(apktool --version)"
  echo "adb:      $(adb version | head -n 1)"
  echo "chromium: $(chromium --version 2>/dev/null)"
  echo "tshark:   $(tshark --version | head -n 1)"
  echo "capinfos: $(capinfos --version | head -n 1)"
  TERM=xterm python3 -c "import pwnlib; print(\"pwntools:\", pwnlib.version)"
'

echo "==> Provider inventory"
docker compose run --rm --no-deps -T rea rea providers --format json 2>/dev/null | jq -r '
  "native analysis providers:",
  (.analysis_provider_candidates[] |
    "  \(.provider.id): \(.availability.status)" +
    (if .availability.code then " (\(.availability.code))" else "" end)),
  "",
  "tool capabilities:",
  (.capabilities[] |
    "  \(.provider.id): " +
    (([.groups[] | select(.available)] | length | tostring)) + "/" +
    (([.groups[]] | length | tostring)) + " groups available")
'

echo "==> Starting HTTP MCP server"
# --wait uses the service healthcheck, avoiding a race where Docker publishes
# the host port before REA has started listening.
docker compose up -d --wait --wait-timeout 120

port="${REA_PORT:-8765}"
published="$(docker compose port rea 8765 2>/dev/null || true)"
if [[ -n "$published" ]]; then
  port="${published##*:}"
fi
echo "==> Waiting for http://127.0.0.1:${port}/mcp"
ready=0
for _ in $(seq 1 60); do
  if timeout 1 bash -c "</dev/tcp/127.0.0.1/${port}" 2>/dev/null; then
    ready=1
    break
  fi
  sleep 1
done
if [[ $ready -ne 1 ]]; then
  echo "server did not become reachable" >&2
  docker compose logs --tail=120 rea >&2 || true
  exit 1
fi

echo "==> MCP initialize / tools/list / tools/call"
docker compose exec -T rea node /opt/rea-tools/mcp-smoke.mjs

echo "==> OpenCode status"
if command -v opencode >/dev/null 2>&1; then
  if [[ -f opencode.jsonc || -f opencode.json ]]; then
    opencode mcp list || true
  else
    echo "No OpenCode config in this directory yet."
    echo "Copy opencode.example.jsonc to opencode.jsonc (or run 'opencode mcp add') to register REA."
  fi
else
  echo "opencode not found on PATH; skipping"
fi

echo
echo "REA MCP is running at http://127.0.0.1:${port}/mcp"
echo "OpenCode config is documented in README.md (section 'Configure OpenCode')."

if [[ $stop -eq 1 ]]; then
  echo "==> Stopping service"
  docker compose down
fi
