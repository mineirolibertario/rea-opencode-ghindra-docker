//
// gcc test.c -o test -lm
//

#include <stdio.h>

int main(void) {
	int i;
	char c;
	float f;

	i = 1 < 10;
	c = 0xfa;
	f = 12.324;

	printf("magic number: %g\n", (double) i + (double) c + (double) f);

	return 0;
}
